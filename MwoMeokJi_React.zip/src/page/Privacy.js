import Navigation from "../components/Navigation"

const Privacy = () => {
    return(
        <div>
            <Navigation/>
            <h2>Privacy Page</h2>
        </div>
    )
}

export default Privacy